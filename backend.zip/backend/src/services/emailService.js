 const nodemailer = require("nodemailer");

const MAX_EMAIL_ATTEMPTS = 3;
const RETRY_DELAY = 5000; // 5 seconds

const transporter = nodemailer.createTransport({
    service: "gmail",

    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_APP_PASSWORD,
    },
});

/**
 * Send a single email
 */
const sendEmail = async ({
    to,
    subject,
    text,
}) => {
    try {
        const info = await transporter.sendMail({
            from:
                process.env.EMAIL_FROM ||
                process.env.EMAIL_USER,

            to,
            subject,
            text,
        });

        console.log(
            `Email sent successfully to: ${to}`
        );

        console.log(
            `Email message ID: ${info.messageId}`
        );

        return info;
    } catch (error) {
        console.error(
            `Email sending failed to ${to}:`,
            error.message
        );

        throw error;
    }
};

/**
 * Wait for a specified amount of time
 */
const wait = (milliseconds) => {
    return new Promise((resolve) => {
        setTimeout(resolve, milliseconds);
    });
};

/**
 * Send email with maximum 3 attempts
 *
 * Attempt 1
 *    ↓ failed
 * Wait 5 seconds
 *    ↓
 * Attempt 2
 *    ↓ failed
 * Wait 5 seconds
 *    ↓
 * Attempt 3
 *    ↓
 * Success OR final failure
 */
const sendEmailWithRetry = async ({
    to,
    subject,
    text,
}) => {
    let lastError = null;

    for (
        let attempt = 1;
        attempt <= MAX_EMAIL_ATTEMPTS;
        attempt++
    ) {
        try {
            console.log(
                `[EMAIL] Attempt ${attempt}/${MAX_EMAIL_ATTEMPTS} -> ${to}`
            );

            const emailInfo = await sendEmail({
                to,
                subject,
                text,
            });

            console.log(
                `[EMAIL] Email delivered successfully on attempt ${attempt}/${MAX_EMAIL_ATTEMPTS}`
            );

            return {
                success: true,

                attemptCount: attempt,

                messageId:
                    emailInfo?.messageId || null,

                error: null,
            };
        } catch (error) {
            lastError = error;

            console.error(
                `[EMAIL] Attempt ${attempt}/${MAX_EMAIL_ATTEMPTS} failed -> ${to}:`,
                error.message
            );

            // Don't wait after the final attempt
            if (attempt < MAX_EMAIL_ATTEMPTS) {
                console.log(
                    `[EMAIL] Retrying in ${
                        RETRY_DELAY / 1000
                    } seconds...`
                );

                await wait(RETRY_DELAY);
            }
        }
    }

    console.error(
        `[EMAIL] All ${MAX_EMAIL_ATTEMPTS} attempts failed -> ${to}`
    );

    return {
        success: false,

        attemptCount: MAX_EMAIL_ATTEMPTS,

        messageId: null,

        error:
            lastError?.message ||
            "Email sending failed after 3 attempts",
    };
};

/**
 * Verify Gmail SMTP connection
 *
 * Useful for checking whether EMAIL_USER
 * and EMAIL_APP_PASSWORD are configured correctly.
 */
const verifyEmailTransporter = async () => {
    try {
        await transporter.verify();

        console.log(
            "Email transporter is ready"
        );

        return true;
    } catch (error) {
        console.error(
            "Email transporter verification failed:",
            error.message
        );

        return false;
    }
};

module.exports = {
    sendEmail,
    sendEmailWithRetry,
    verifyEmailTransporter,
};