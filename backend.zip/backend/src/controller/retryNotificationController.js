const Notification = require("../models/Notification");

const {
    sendEmailWithRetry,
} = require("../services/emailService");

/**
 * ============================================================
 * RESEND FAILED EMAIL
 * ============================================================
 *
 * Compliance Officer can manually resend a failed
 * expiry notification.
 *
 * Important:
 * - Only FAILED notifications can be resent.
 * - Organization isolation is enforced.
 * - The SAME notification is updated.
 * - A new notification is NOT created.
 * - Email is attempted up to 3 times.
 */
const resendNotificationEmail = async (req, res) => {
    try {
        const { notificationId } = req.params;

        // =====================================================
        // Find notification inside officer's organization
        // =====================================================

        const notification = await Notification.findOne({
            _id: notificationId,
            organizationId: req.user.organizationId,
        });

        if (!notification) {
            return res.status(404).json({
                success: false,
                message: "Notification not found",
            });
        }

        // =====================================================
        // Only FAILED emails can be resent
        // =====================================================

        if (notification.emailStatus !== "FAILED") {
            return res.status(400).json({
                success: false,
                message:
                    "Only failed email notifications can be resent",
            });
        }

        // =====================================================
        // Validate stored email
        // =====================================================

        if (!notification.email) {
            return res.status(400).json({
                success: false,
                message:
                    "No email address is available for this notification",
            });
        }

        // =====================================================
        // Send email with 3-attempt retry mechanism
        // =====================================================

        console.log(
            `[RESEND] Starting resend for notification ${notification._id}`
        );

        const emailResult = await sendEmailWithRetry({
            to: notification.email,
            subject: notification.title,
            text: notification.message,
        });

        // =====================================================
        // Update SAME notification
        // =====================================================

        notification.attemptCount =
            emailResult.attemptCount;

        notification.lastAttemptAt = new Date();

        notification.resendCount =
            (notification.resendCount || 0) + 1;

        // =====================================================
        // Email successfully sent
        // =====================================================

        if (emailResult.success) {
            notification.emailStatus = "SENT";

            notification.emailMessageId =
                emailResult.messageId;

            notification.emailError = null;

            notification.emailSentAt = new Date();

            await notification.save();

            console.log(
                `[RESEND] Email successfully resent to ${notification.email}`
            );

            return res.status(200).json({
                success: true,
                message:
                    "Notification email resent successfully",
                data: {
                    notificationId:
                        notification._id,

                    emailStatus:
                        notification.emailStatus,

                    attemptCount:
                        notification.attemptCount,

                    resendCount:
                        notification.resendCount,

                    emailSentAt:
                        notification.emailSentAt,
                },
            });
        }

        // =====================================================
        // All 3 attempts failed
        // =====================================================

        notification.emailStatus = "FAILED";

        notification.emailMessageId = null;

        notification.emailError =
            emailResult.error;

        notification.emailSentAt = null;

        await notification.save();

        console.error(
            `[RESEND] All 3 resend attempts failed for ${notification.email}`
        );

        return res.status(500).json({
            success: false,
            message:
                "Email resend failed after 3 attempts",
            data: {
                notificationId:
                    notification._id,

                emailStatus:
                    notification.emailStatus,

                attemptCount:
                    notification.attemptCount,

                resendCount:
                    notification.resendCount,

                emailError:
                    notification.emailError,
            },
        });
    } catch (error) {
        console.error(
            "Resend notification email error:",
            error
        );

        return res.status(500).json({
            success: false,
            message:
                "Failed to resend notification email",
            error: error.message,
        });
    }
};

module.exports = {
    resendNotificationEmail,
};