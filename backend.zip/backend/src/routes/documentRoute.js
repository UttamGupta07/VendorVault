const express = require("express");
const router = express.Router();

const upload = require("../middleware/upload");

const authorizeRoles = require("../middleware/authorizeRoles");
const protect = require("../middleware/authMiddleware");

const {
  uploadVendorDocument,
  getPendingReviewDocuments,
  getDocumentForReview,
  reviewDocument,
  getAllDocuments,
  retryDocumentExtraction,
  getExpiryTracker,
} = require("../controller/documentController");

// ==========================================
// Vendor uploads document
// ==========================================

router.post(
  "/upload",
  protect,
  upload.single("document"),
  uploadVendorDocument
);

// ==========================================
// Compliance Officer
// Get documents pending review
// ==========================================

router.get(
  "/pending-review",
  protect,
  authorizeRoles("COMPLIANCE_OFFICER"),
  getPendingReviewDocuments
);

router.get(
  "/",
  protect,
  authorizeRoles("COMPLIANCE_OFFICER"),
  getAllDocuments
);

// ==========================================
// Compliance Officer
// Get single document for review
// ==========================================

router.post(
  "/:id/retry-extraction",
  protect,
  authorizeRoles("COMPLIANCE_OFFICER"),
  retryDocumentExtraction
);

router.get(
  "/expiry-tracker",
  protect,
  authorizeRoles("COMPLIANCE_OFFICER"),
  getExpiryTracker
); 

router.get(
  "/:id",
  protect,
  authorizeRoles("COMPLIANCE_OFFICER"),
  getDocumentForReview
);

// ==========================================
// Compliance Officer
// Approve / Reject document
// ==========================================

router.put(
  "/:id/review",
  protect,
  authorizeRoles("COMPLIANCE_OFFICER"),
  reviewDocument
);

module.exports = router;