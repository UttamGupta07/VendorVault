 require("dotenv").config();

const { Worker } = require("bullmq");

const connectDB = require("../db/db");
const redisConnection = require("../config/redis");

const VendorDocument = require("../models/VendorDocument");
const Vendor = require("../models/Vendor");
const Notification = require("../models/Notification");

const { sendEmail } = require("../services/emailService");

// =====================================================
// CONFIGURATION
// =====================================================

const QUEUE_NAME = "expiry-reminder";

// Maximum email attempts for one delivery cycle
const MAX_EMAIL_ATTEMPTS = 3;

// Delay between failed attempts
// 5 seconds
const RETRY_DELAY = 5000;

// =====================================================
// HELPER: WAIT
// =====================================================

const wait = (milliseconds) => {
    return new Promise((resolve) => {
        setTimeout(resolve, milliseconds);
    });
};

// =====================================================
// HELPER: SEND EMAIL WITH 3 ATTEMPTS
// =====================================================

const sendEmailWithRetry = async ({
    to,
    subject,
    text,
}) => {
    let lastError = null;

    for (
        let attempt = 1;
        attempt <= MAX_EMAIL_ATTEMPTS;
        attempt++
    ) {
        try {
            console.log(
                `📧 Email attempt ${attempt}/${MAX_EMAIL_ATTEMPTS}`
            );

            console.log(`📨 Sending email to: ${to}`);

            const emailInfo = await sendEmail({
                to,
                subject,
                text,
            });

            console.log(
                `✅ Email sent successfully on attempt ${attempt}`
            );

            console.log(
                `📩 Message ID: ${emailInfo?.messageId || "N/A"}`
            );

            return {
                success: true,
                attemptCount: attempt,
                messageId:
                    emailInfo?.messageId || null,
                error: null,
            };
        } catch (error) {
            lastError = error;

            console.error(
                `❌ Email attempt ${attempt}/${MAX_EMAIL_ATTEMPTS} failed`
            );

            console.error(
                `❌ Error: ${error?.message || "Unknown error"}`
            );

            // Retry only if attempts are remaining
            if (attempt < MAX_EMAIL_ATTEMPTS) {
                console.log(
                    `⏳ Retrying email in ${
                        RETRY_DELAY / 1000
                    } seconds...`
                );

                await wait(RETRY_DELAY);
            }
        }
    }

    // =================================================
    // ALL 3 ATTEMPTS FAILED
    // =================================================

    console.error(
        `🚨 Email permanently failed after ${MAX_EMAIL_ATTEMPTS} attempts`
    );

    return {
        success: false,
        attemptCount: MAX_EMAIL_ATTEMPTS,
        messageId: null,
        error:
            lastError?.message ||
            "Email sending failed after 3 attempts",
    };
};

// =====================================================
// HELPER: BUILD NOTIFICATION CONTENT
// =====================================================

const buildNotificationContent = ({
    reminderType,
    document,
    vendor,
}) => {
    const expiryDate = new Date(
        document.expiryDate
    );

    const formattedExpiryDate =
        expiryDate.toLocaleDateString("en-IN", {
            day: "2-digit",
            month: "short",
            year: "numeric",
        });

    let title;
    let message;

    switch (reminderType) {
        // =============================================
        // 15 DAYS
        // =============================================

        case "15_DAY":
            title = "Document Expiring in 15 Days";

            message =
                `The document "${document.documentType}" ` +
                `for vendor "${vendor.companyName}" ` +
                `will expire on ${formattedExpiryDate}. ` +
                `Please renew the document before expiry.`;

            break;

        // =============================================
        // 7 DAYS
        // =============================================

        case "7_DAY":
            title = "Document Expiring in 7 Days";

            message =
                `The document "${document.documentType}" ` +
                `for vendor "${vendor.companyName}" ` +
                `will expire on ${formattedExpiryDate}. ` +
                `Only 7 days remain. Please take action immediately.`;

            break;

        // =============================================
        // 1 DAY
        // =============================================

        case "1_DAY":
            title = "Document Expiring Tomorrow";

            message =
                `The document "${document.documentType}" ` +
                `for vendor "${vendor.companyName}" ` +
                `will expire on ${formattedExpiryDate}. ` +
                `Please renew the document immediately.`;

            break;

        // =============================================
        // EXPIRED 1 DAY
        // =============================================

        case "EXPIRED_1_DAY":
            title = "Document Expired";

            message =
                `The document "${document.documentType}" ` +
                `for vendor "${vendor.companyName}" ` +
                `expired on ${formattedExpiryDate}. ` +
                `Please upload a renewed document immediately.`;

            break;

        // =============================================
        // EXPIRED 3 DAYS
        // =============================================

        case "EXPIRED_3_DAY":
            title = "Document Expired for 3 Days";

            message =
                `The document "${document.documentType}" ` +
                `for vendor "${vendor.companyName}" ` +
                `has been expired for 3 days. ` +
                `Immediate action is required.`;

            break;

        // =============================================
        // EXPIRED 7 DAYS
        // =============================================

        case "EXPIRED_7_DAY":
            title = "Document Expired for 7 Days";

            message =
                `The document "${document.documentType}" ` +
                `for vendor "${vendor.companyName}" ` +
                `has been expired for 7 days. ` +
                `Please upload a valid document immediately ` +
                `to restore compliance.`;

            break;

        // =============================================
        // DEFAULT
        // =============================================

        default:
            title = "Document Expiry Notification";

            message =
                `The document "${document.documentType}" ` +
                `for vendor "${vendor.companyName}" ` +
                `requires attention.`;

            break;
    }

    return {
        title,
        message,
    };
};

// =====================================================
// BULLMQ WORKER
// =====================================================

const worker = new Worker(
    QUEUE_NAME,

    async (job) => {
        console.log("");
        console.log("============================================");
        console.log("🚀 EXPIRY REMINDER JOB STARTED");
        console.log("============================================");

        console.log("Job ID:", job.id);
        console.log("Job Name:", job.name);
        console.log("Job Data:", job.data);

        console.log("============================================");

        const {
            documentId,
            vendorId,
            reminderType,
        } = job.data;

        // =================================================
        // 1. FIND DOCUMENT
        // =================================================

        const document =
            await VendorDocument.findById(
                documentId
            );

        if (!document) {
            console.log(
                `⚠️ Document not found: ${documentId}`
            );

            return {
                success: false,
                reason: "DOCUMENT_NOT_FOUND",
            };
        }

        // =================================================
        // 2. VERIFY DOCUMENT BELONGS TO VENDOR
        // =================================================

        if (
            document.vendorId.toString() !==
            vendorId.toString()
        ) {
            console.error(
                `❌ Document ${documentId} does not belong to vendor ${vendorId}`
            );

            return {
                success: false,
                reason:
                    "VENDOR_DOCUMENT_MISMATCH",
            };
        }

        // =================================================
        // 3. FIND VENDOR
        // =================================================

        const vendor =
            await Vendor.findById(vendorId);

        if (!vendor) {
            console.log(
                `⚠️ Vendor not found: ${vendorId}`
            );

            return {
                success: false,
                reason: "VENDOR_NOT_FOUND",
            };
        }

        // =================================================
        // 4. CHECK ORGANIZATION
        // =================================================

        if (!vendor.organizationId) {
            console.error(
                `❌ Vendor ${vendorId} does not have organizationId`
            );

            return {
                success: false,
                reason:
                    "ORGANIZATION_NOT_FOUND",
            };
        }

        // =================================================
        // 5. CHECK EMAIL
        // =================================================

        if (!vendor.email) {
            console.error(
                `❌ Vendor ${vendorId} does not have an email`
            );

            return {
                success: false,
                reason:
                    "VENDOR_EMAIL_NOT_FOUND",
            };
        }

        // =================================================
        // 6. CHECK EXPIRY DATE
        // =================================================

        if (!document.expiryDate) {
            console.log(
                `⚠️ Document ${documentId} has no expiry date`
            );

            return {
                success: false,
                reason:
                    "EXPIRY_DATE_NOT_FOUND",
            };
        }

        // =================================================
        // 7. DUPLICATE NOTIFICATION CHECK
        // =================================================

        const existingNotification =
            await Notification.findOne({
                organizationId:
                    vendor.organizationId,

                vendorId: vendor._id,

                documentId: document._id,

                reminderType,
            });

        if (existingNotification) {
            console.log(
                `ℹ️ Notification already exists: ${existingNotification._id}`
            );

            console.log(
                `📌 Email Status: ${existingNotification.emailStatus}`
            );

            return {
                success: true,
                skipped: true,
                reason:
                    "NOTIFICATION_ALREADY_EXISTS",
                notificationId:
                    existingNotification._id,
            };
        }

        // =================================================
        // 8. BUILD NOTIFICATION CONTENT
        // =================================================

        const {
            title,
            message,
        } = buildNotificationContent({
            reminderType,
            document,
            vendor,
        });

        console.log("");
        console.log("============================================");
        console.log("📋 NOTIFICATION DETAILS");
        console.log("============================================");

        console.log("Organization:", vendor.organizationId);
        console.log("Vendor:", vendor.companyName);
        console.log("Vendor ID:", vendor._id);
        console.log("Document ID:", document._id);
        console.log("Reminder Type:", reminderType);
        console.log("Email:", vendor.email);
        console.log("Title:", title);

        console.log("============================================");

        // =================================================
        // 9. SEND EMAIL WITH 3 ATTEMPTS
        // =================================================

        const emailResult =
            await sendEmailWithRetry({
                to: vendor.email,

                subject: title,

                text: message,
            });

        // =================================================
        // 10. DETERMINE EMAIL STATUS
        // =================================================

        let emailStatus = "FAILED";

        let emailMessageId = null;

        let emailError = null;

        let emailSentAt = null;

        if (emailResult.success) {
            emailStatus = "SENT";

            emailMessageId =
                emailResult.messageId;

            emailSentAt = new Date();

            emailError = null;

            console.log("");
            console.log(
                "✅ FINAL EMAIL STATUS: SENT"
            );
        } else {
            emailStatus = "FAILED";

            emailMessageId = null;

            emailSentAt = null;

            emailError =
                emailResult.error;

            console.log("");
            console.log(
                "❌ FINAL EMAIL STATUS: FAILED"
            );

            console.log(
                "❌ Reason:",
                emailError
            );
        }

        // =================================================
        // 11. ALWAYS CREATE NOTIFICATION
        // =================================================
        //
        // Even if email fails after 3 attempts,
        // we save the notification.
        //
        // Compliance Officer can then see the failure
        // and use the Resend button.
        //
        // =================================================

        const notification =
            await Notification.create({
                organizationId:
                    vendor.organizationId,

                vendorId: vendor._id,

                documentId: document._id,

                reminderType,

                title,

                message,

                email: vendor.email,

                emailStatus,

                emailMessageId,

                emailError,

                emailSentAt,

                resendCount: 0,

                attemptCount:
                    emailResult.attemptCount,

                lastAttemptAt: new Date(),

                isRead: false,
            });

        // =================================================
        // 12. FINAL LOG
        // =================================================

        console.log("");
        console.log("============================================");
        console.log("🔔 NOTIFICATION CREATED");
        console.log("============================================");

        console.log(
            "Notification ID:",
            notification._id
        );

        console.log(
            "Organization ID:",
            notification.organizationId
        );

        console.log(
            "Vendor ID:",
            notification.vendorId
        );

        console.log(
            "Document ID:",
            notification.documentId
        );

        console.log(
            "Reminder Type:",
            notification.reminderType
        );

        console.log(
            "Email:",
            notification.email
        );

        console.log(
            "Email Status:",
            notification.emailStatus
        );

        console.log(
            "Attempt Count:",
            notification.attemptCount
        );

        console.log(
            "Resend Count:",
            notification.resendCount
        );

        console.log("============================================");
        console.log(
            "🏁 EXPIRY REMINDER JOB COMPLETED"
        );
        console.log("============================================");
        console.log("");

        // =================================================
        // IMPORTANT
        // =================================================
        //
        // DO NOT throw emailResult.error here.
        //
        // The worker has already tried 3 times.
        // The FAILED status has been stored in MongoDB.
        //
        // If we throw here, BullMQ may consider the job
        // failed and retry the entire job, which could
        // create unwanted duplicate processing.
        //
        // =================================================

        return {
            success: emailResult.success,

            notificationId:
                notification._id,

            emailStatus,

            attemptCount:
                emailResult.attemptCount,
        };
    },

    {
        connection: redisConnection,

        // Process up to 5 jobs simultaneously
        concurrency: 5,
    }
);

// =====================================================
// WORKER COMPLETED
// =====================================================

worker.on("completed", (job, result) => {
    console.log("");
    console.log("============================================");
    console.log("✅ BULLMQ JOB COMPLETED");
    console.log("============================================");

    console.log("Job ID:", job.id);

    console.log("Result:", result);

    console.log("============================================");
});

// =====================================================
// WORKER FAILED
// =====================================================

worker.on("failed", (job, error) => {
    console.error("");
    console.error("============================================");
    console.error("❌ BULLMQ JOB FAILED");
    console.error("============================================");

    console.error(
        "Job ID:",
        job?.id
    );

    console.error(
        "Error:",
        error?.message
    );

    console.error("============================================");
});

// =====================================================
// WORKER ERROR
// =====================================================

worker.on("error", (error) => {
    console.error("");
    console.error("============================================");
    console.error("❌ BULLMQ WORKER ERROR");
    console.error("============================================");

    console.error(error);

    console.error("============================================");
});

// =====================================================
// START WORKER
// =====================================================

const startWorker = async () => {
    try {
        await connectDB();

        console.log("");
        console.log("============================================");
        console.log("🚀 EXPIRY REMINDER WORKER STARTED");
        console.log("============================================");

        console.log(
            "Queue:",
            QUEUE_NAME
        );

        console.log(
            "Maximum Email Attempts:",
            MAX_EMAIL_ATTEMPTS
        );

        console.log(
            "Retry Delay:",
            `${RETRY_DELAY / 1000} seconds`
        );

        console.log(
            "Concurrency:",
            5
        );

        console.log("============================================");
        console.log("");
    } catch (error) {
        console.error(
            "❌ Failed to start expiry reminder worker:"
        );

        console.error(error);

        process.exit(1);
    }
};

// =====================================================
// START
// =====================================================

startWorker();